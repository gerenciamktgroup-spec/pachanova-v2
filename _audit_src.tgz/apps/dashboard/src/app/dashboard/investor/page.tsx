export const dynamic = 'force-dynamic';

import { RouteBreadcrumbs, ErrorState, LoadingState } from "@/components/mission";
import { SafeActionButton } from "@/components/mission/SafeActionButton";
import { 
  InvestorPortfolioHero, 
  ProRataLandCardV2, 
  InvestorLedgerPanel, 
  InvestorKycStatusPanel, 
  GenesisDemoActionCard, 
  InvestorWalletStatusPanel,
  LandbankManagementClient 
} from "@/components/product";
import { InvestorDashboardView } from "@/types/product";
import { Suspense } from "react";
import { NextStepCard } from "@/components/product/NextStepCard";
import { JourneyProgressRail } from "@/components/product/JourneyProgressRail";
import { investorJourney } from "@/lib/navigation/userJourneys";

import { db } from "@/server/db";
import { schema } from "@pachanova/database";
import { eq } from "drizzle-orm";

async function fetchInvestorData(): Promise<InvestorDashboardView | null> {
  try {
    // 1. Fetch default holder investor from database
    const investor = await db.query.investors.findFirst({
      where: eq(schema.investors.email, "demo.investor.holder@pachanova.local")
    });

    if (!investor) {
      throw new Error("Default holder investor not found in database");
    }

    // 2. Fetch balance
    const balance = await db.query.balances.findFirst({
      where: eq(schema.balances.investorId, investor.id)
    });

    // 3. Fetch recent transactions
    const rawTxs = await db.query.transactions.findMany({
      where: eq(schema.transactions.senderId, investor.id),
      orderBy: (fields, { desc }) => [desc(fields.createdAt)],
      limit: 10
    });

    const recentTransactions: InvestorDashboardView["recentTransactions"] = rawTxs.map((tx) => {
      const operationType = tx.type === "transfer"
        ? "TRANSFER"
        : tx.type === "burn"
          ? "BURN"
          : tx.type === "mint"
            ? "MINT"
            : "GENESIS_PURCHASE";

      const status = tx.status === "completed"
        ? "confirmed"
        : tx.status === "failed"
          ? "failed"
          : "pending";

      return {
        id: tx.id,
        amount: tx.amount,
        operationType,
        txHash: tx.txHash,
        status,
        timestamp: tx.createdAt.toISOString(),
      };
    });

    return {
      investor: {
        id: investor.id,
        fullName: `${investor.firstName || ''} ${investor.lastName || ''}`.trim() || "Inversor Demo",
        email: investor.email,
        kycStatus: investor.kycStatus || "approved",
        isVerified: investor.isVerified || true,
        balance: {
          investorId: investor.id,
          availableTokens: balance?.availableTokens || "0",
          lockedTokens: balance?.lockedTokens || "0",
          availableUsd: balance?.availableUsd || "0",
          lockedUsd: "0",
          lastUpdated: balance?.lastUpdatedAt?.toISOString() || new Date().toISOString()
        }
      },
      recentTransactions,
      kycVerificationProvider: "SIMULATED",
      paymentsReadiness: {
        provider: "MERCADOPAGO",
        status: "PENDING_CREDENTIALS",
        lastPing: null,
        message: "No credentials"
      },
      contractReadiness: {
        provider: "FOUNDRY",
        status: "PENDING_FOUNDRY",
        lastPing: null,
        message: "Node inactive"
      }
    };
  } catch (error) {
    console.error("Error fetching investor view model from DB, using fallback:", error);
    // Return a high-fidelity fallback in case database connection fails on Vercel
    return {
      investor: {
        id: "demo-investor-123",
        fullName: "Inversor Demo (Respaldo)",
        email: "investor@pachanova.local",
        kycStatus: "approved",
        isVerified: true,
        balance: {
          investorId: "demo-investor-123",
          availableTokens: "1250",
          lockedTokens: "0",
          availableUsd: "5000",
          lockedUsd: "0",
          lastUpdated: new Date().toISOString()
        }
      },
      recentTransactions: [],
      kycVerificationProvider: "SIMULATED",
      paymentsReadiness: {
        provider: "MERCADOPAGO",
        status: "PENDING_CREDENTIALS",
        lastPing: null,
        message: "No credentials"
      },
      contractReadiness: {
        provider: "FOUNDRY",
        status: "PENDING_FOUNDRY",
        lastPing: null,
        message: "Node inactive"
      }
    };
  }
}

async function InvestorDashboardContent() {
  const view = await fetchInvestorData();

  if (!view) {
    return <ErrorState title="Panel no disponible" message="No se pudo construir el ViewModel del inversor. Verifica PostgreSQL y ejecuta el reset determinista del entorno demo." />;
  }

  return (
    <div className="space-y-8 pb-24">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
        <RouteBreadcrumbs items={[
          { label: "Dashboard" },
          { label: "Panel Inversor" }
        ]} />
        <div className="flex flex-wrap gap-2">
          {/* Fase 6: Ver todos los avances immediate + full hub/identity cross-links */}
          <SafeActionButton label="Ver todos los avances" href="/demo/showcase#phase4-hologram-landbank" variant="primary" />
          <SafeActionButton label="Ver avances (Yields/Gov/Borrow E2E)" href="/demo/showcase#phase4-hologram-landbank" variant="ghost" />
          <SafeActionButton label="Hub Central" href="/demo/showcase" variant="ghost" />
          <SafeActionButton label="Identity/KYC" href="/demo/integrations" variant="ghost" />
          <SafeActionButton label="P2P Marketplace (5PNC ties)" href="/dashboard/investor/marketplace" variant="ghost" />
          <SafeActionButton label="Historial Genesis" href="/dashboard/investor/genesis" variant="ghost" />
          <SafeActionButton label="Disclaimers" href="/dashboard/investor/disclosures" variant="ghost" />
          <SafeActionButton label="Integraciones" href="/demo/integrations" variant="ghost" />
          <SafeActionButton label="Admin Landbank" href="/dashboard/admin/landbank" variant="ghost" />
        </div>
      </div>

      <JourneyProgressRail journey={investorJourney} currentStepId="i1" />

      <NextStepCard 
        dataTestId="next-step-card-investor"
        contextLabel="Panel Inversor"
        title="Tu Portafolio de Fracciones de Tierra — PachaNova"
        explanation="¡Bienvenido a tu panel de control! Aquí puedes ver y gestionar las fracciones de tierra digitalizadas que posees (llamadas 'Tokens RWA') en proyectos reales como San Bartolo. Este entorno te permite experimentar de forma segura cómo funciona el mercado inmobiliario del futuro: puedes comprar fracciones de terrenos, venderlas a otros usuarios, solicitar financiamiento respaldado por tus tierras, y ver cómo tus ganancias se acumulan y reinvierten automáticamente (Ciclo de Reinversión)."
        nextStep="Explora tus propiedades interactivas abajo para simular compras, ventas, préstamos y cobro de rentas."
        primaryAction={{ label: "Simular Compra Inicial", href: "/dashboard/investor/genesis", intent: "navigate" }}
        secondaryAction={{ label: "Ver Libro de Registro", href: "/dashboard/investor/ledger", intent: "navigate" }}
        status="GO"
      />

      <InvestorPortfolioHero view={view} />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          {/* Fase 6 Polish: Full Hologram Landbank client (5 PNC interactive E2E flows + P2P ties + borrow/claim/gov + identity/hub everywhere) - Phase 4 visuals base */}
          <LandbankManagementClient />
          <InvestorLedgerPanel view={view} />
          {/* Legacy simple pro-rata kept for reference (below) */}
          <ProRataLandCardV2 view={view} />
        </div>
        
        <div className="space-y-8">
          <GenesisDemoActionCard view={view} />
          <InvestorKycStatusPanel view={view} />
          <InvestorWalletStatusPanel view={view} />
        </div>
      </div>
    </div>
  );
}

export default function InvestorDashboardPage() {
  return (
    <Suspense fallback={<LoadingState message="Cargando estado del inversor simulado..." />}>
      <InvestorDashboardContent />
    </Suspense>
  );
}
